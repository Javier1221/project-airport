import pymysql
from app import app
from db_config import mysql
from flask import render_template,request


@app.route('/')
def index():
    try:
        conn = mysql.connect()
        cur = conn.cursor(pymysql.cursors.DictCursor)
        id =request.args.get('dato')
        
        if id:
          cur.execute('''SELECT * FROM areo WHERE airport_id = %s ;''',(id))
        else:
            cur.execute('SELECT * FROM areo;')
        
        data = cur.fetchall()
        cur.close()
        return render_template("index.html", airport=data)
    except Exception as e:
        print(e)
        return render_template("index.html")


@app.route('/distance')
def distance():
    try:
        id =request.args.get('dato')
        conn = mysql.connect()
        cur = conn.cursor(pymysql.cursors.DictCursor)
        if id:
            cur.execute('''SELECT * FROM distance WHERE Origin = %s ;''',(id))
        else:
            cur.execute('SELECT * FROM distance;')
        data = cur.fetchall()
        cur.close()
        return render_template("distance.html", dist=data)
    except Exception as e:
        print(e)
        return render_template("distance.html")

@app.route('/busqueda',methods=['GET','POST'])
def busqueda():
    try:
        id =request.args.get('dato')
        print(id)
        conn = mysql.connect()
        cur = conn.cursor(pymysql.cursors.DictCursor)
        cur.execute('''SELECT * FROM distance WHERE Origin = %s ;''',(id))
        data = cur.fetchall()
        cur.close()
        return render_template("busqueda.html", busq=data)
    except Exception as e:
        print(e)
        return render_template("busqueda.html")
  

if __name__ == '__main__':
    app.run(debug=True)
